import pygame
import asyncio
import platform
from collections import deque
import json
import os
import copy  # Thêm import copy để sử dụng deepcopy

# Khởi tạo Pygame
pygame.init()

# Cấu hình game
WIDTH, HEIGHT = 420, 480
TILE_SIZE = 20
FPS = 10

# Màu sắc
BLACK = (0, 0, 0)
YELLOW = (255, 255, 0)
RED = (255, 0, 0)
WHITE = (255, 255, 255)

# Ma trận mê cung cho Easy
maze_easy = [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,0,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,1,1,2,1,2,1,2,1,2,1,1,1,1,2,1,2,1],
    [1,2,1,0,0,1,2,1,0,0,0,0,0,1,0,0,1,2,1,2,1],
    [1,2,1,0,0,1,2,1,0,0,0,0,0,1,0,0,1,2,1,2,1],
    [1,2,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,2,1,2,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,2,1],
    [1,2,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,2,1],
    [1,2,2,2,2,2,2,2,2,2,0,2,2,2,2,2,2,2,2,2,1],
    [1,1,1,1,1,1,2,1,1,0,0,0,1,1,1,1,1,1,1,1,1],
    [1,1,1,1,1,1,2,1,1,0,0,0,1,1,1,1,1,1,1,1,1],
    [1,2,2,2,2,2,2,2,2,2,0,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,2,1],
    [1,2,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,2,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,2,1,2,1],
    [1,2,1,0,0,1,2,1,0,0,0,0,0,1,0,0,1,2,1,2,1],
    [1,2,1,0,0,1,2,1,0,0,0,0,0,1,0,0,1,2,1,2,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
]

# Ma trận mê cung cho Medium
maze_medium = [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,0,2,2,2,1,2,2,2,1,2,2,2,1,2,2,2,1,2,2,1],
    [1,2,1,1,2,1,1,1,2,1,2,1,2,1,2,1,1,1,2,1,1],
    [1,2,2,0,2,2,2,2,2,2,2,2,2,2,2,2,2,0,2,2,1],
    [1,1,1,0,1,1,2,1,1,1,1,1,1,1,1,2,1,0,1,1,1],
    [1,2,2,2,2,1,2,2,2,1,2,1,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,2,1,1,1,2,1,2,1,2,1,1,1,2,1,1,2,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1],
    [1,2,2,2,2,1,2,2,2,2,0,2,2,2,2,2,1,2,2,2,1],
    [1,2,1,1,2,1,1,1,1,0,0,0,1,1,1,1,1,2,1,2,1],
    [1,2,2,2,2,2,2,2,2,2,0,2,2,2,2,2,2,2,2,2,1],
    [1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,2,1,1,1,2,1,2,1,2,1,1,1,2,1,1,2,1],
    [1,2,2,1,2,2,2,2,2,1,2,1,2,2,2,2,2,2,1,2,1],
    [1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,2,1,1,1,2,1,2,1,2,1,1,1,2,1,1,2,1],
    [1,2,2,2,2,1,2,2,2,1,2,2,2,1,2,2,2,2,2,2,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
]

# Ma trận mê cung cho Hard
maze_hard = [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,0,2,2,1,2,2,1,2,2,1,2,2,1,2,2,1,2,2,2,1],
    [1,2,1,2,1,1,2,1,1,2,1,2,1,1,2,1,1,2,1,2,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1],
    [1,2,2,2,2,1,2,2,2,1,2,1,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,2,1,1,1,2,1,2,1,2,1,1,1,2,1,1,2,1],
    [1,2,2,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,2,1],
    [1,1,2,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,2,1],
    [1,2,2,2,2,2,2,2,2,2,0,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,1,1,2,1,1,0,0,0,1,1,1,2,1,1,1,2,1],
    [1,2,2,2,2,2,2,2,2,2,0,2,2,2,2,2,2,2,2,2,1],
    [1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,2,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,2,1,1,1,2,1,2,1,2,1,1,1,2,1,1,2,1],
    [1,2,2,1,2,2,2,2,2,1,2,1,2,2,2,2,2,2,1,2,1],
    [1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,2,1,1,1,2,1,2,1,2,1,1,1,2,1,1,2,1],
    [1,2,2,2,2,1,2,2,2,1,2,2,2,1,2,2,2,1,2,2,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
]

# Model: Quản lý trạng thái và logic game
class GameModel:
    def __init__(self):
        self.maze = maze_easy
        self.pacman = Pacman(1, 1)
        self.ghost = Ghost(10, 10)
        self.score = 0
        self.game_state = "menu"
        self.difficulty = None
        self.mazes = {
            "easy": maze_easy,
            "medium": maze_medium,
            "hard": maze_hard
        }
        self.leaderboard = self.load_leaderboard()

    def load_leaderboard(self):
        try:
            if platform.system() != "Emscripten":
                if os.path.exists("leaderboard.json"):
                    with open("leaderboard.json", "r") as f:
                        return json.load(f)
            return {"easy": [], "medium": [], "hard": []}
        except:
            return {"easy": [], "medium": [], "hard": []}

    def save_leaderboard(self):
        if platform.system() != "Emscripten":
            try:
                with open("leaderboard.json", "w") as f:
                    json.dump(self.leaderboard, f)
            except:
                pass

    def update_leaderboard(self, score, difficulty):
        if score > 0 and difficulty in self.mazes:
            self.leaderboard[difficulty].append(score)
            self.leaderboard[difficulty] = sorted(self.leaderboard[difficulty], reverse=True)[:5]  # Giữ 5 điểm cao nhất
            self.save_leaderboard()

    def reset(self):
        # Kiểm tra nếu difficulty là None, gán mặc định là "easy"
        if self.difficulty is None or self.difficulty not in self.mazes:
            self.difficulty = "easy"
        # Sử dụng deepcopy để tạo bản sao độc lập của mê cung
        self.maze = copy.deepcopy(self.mazes[self.difficulty])
        self.pacman = Pacman(1, 1)  # Tạo mới Pacman để đảm bảo trạng thái sạch
        self.ghost = Ghost(10, 10)
        self.score = 0

    def check_all_dots_eaten(self):
        for row in self.maze:
            if 2 in row:
                return False
        return True

    def update(self, delta_time):
        if self.game_state == "playing":
            if self.difficulty is None or self.difficulty not in self.mazes:
                print("Warning: Difficulty is invalid, resetting to 'easy'")
                self.difficulty = "easy"
            points = self.pacman.move(self.maze)
            self.score += points
            self.ghost.move(self.pacman.x, self.pacman.y, self.maze, delta_time)
            if (self.pacman.x, self.pacman.y) == (self.ghost.x, self.ghost.y):
                self.update_leaderboard(self.score, self.difficulty)
                self.game_state = "game_over"
            if self.check_all_dots_eaten():
                self.update_leaderboard(self.score, self.difficulty)
                self.game_state = "victory"

# View: Quản lý hiển thị
class GameView:
    def __init__(self, screen):
        self.screen = screen

    def render(self, model):
        self.screen.fill(BLACK)
        if model.game_state == "menu":
            font = pygame.font.Font(None, 48)
            title = font.render("Pacman - Select Difficulty", True, WHITE)
            self.screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 50))
            font = pygame.font.Font(None, 36)
            easy = font.render("1. Easy", True, WHITE)
            medium = font.render("2. Medium", True, WHITE)
            hard = font.render("3. Hard", True, WHITE)
            leaderboard = font.render("4. Leaderboard", True, WHITE)
            self.screen.blit(easy, (WIDTH // 2 - easy.get_width() // 2, 150))
            self.screen.blit(medium, (WIDTH // 2 - medium.get_width() // 2, 200))
            self.screen.blit(hard, (WIDTH // 2 - hard.get_width() // 2, 250))
            self.screen.blit(leaderboard, (WIDTH // 2 - leaderboard.get_width() // 2, 300))
        elif model.game_state == "leaderboard":
            font = pygame.font.Font(None, 48)
            title = font.render("Leaderboard", True, WHITE)
            self.screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 50))
            font = pygame.font.Font(None, 36)
            y_offset = 100
            for difficulty in ["easy", "medium", "hard"]:
                text = font.render(f"{difficulty.capitalize()}:", True, WHITE)
                self.screen.blit(text, (50, y_offset))
                y_offset += 30
                scores = model.leaderboard.get(difficulty, [])
                for i, score in enumerate(scores[:5], 1):
                    score_text = font.render(f"{i}. {score}", True, WHITE)
                    self.screen.blit(score_text, (70, y_offset))
                    y_offset += 30
                y_offset += 20
            back = font.render("Press SPACE to return to menu", True, WHITE)
            self.screen.blit(back, (WIDTH // 2 - back.get_width() // 2, y_offset))
        elif model.game_state in ["playing", "paused"]:
            for y in range(len(model.maze)):
                for x in range(len(model.maze[0])):
                    if model.maze[y][x] == 1:
                        pygame.draw.rect(self.screen, (0, 0, 255), (x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE))
                    elif model.maze[y][x] == 2:
                        pygame.draw.circle(self.screen, WHITE, (x * TILE_SIZE + TILE_SIZE // 2, y * TILE_SIZE + TILE_SIZE // 2), 4)
            pygame.draw.circle(self.screen, YELLOW, (model.pacman.x * TILE_SIZE + TILE_SIZE // 2, model.pacman.y * TILE_SIZE + TILE_SIZE // 2), 10)
            pygame.draw.circle(self.screen, RED, (model.ghost.x * TILE_SIZE + TILE_SIZE // 2, model.ghost.y * TILE_SIZE + TILE_SIZE // 2), 10)
            font = pygame.font.Font(None, 36)
            score_text = font.render(f"Score: {model.score}", True, WHITE)
            self.screen.blit(score_text, (10, HEIGHT - 30))
            if model.game_state == "paused":
                font = pygame.font.Font(None, 48)
                text = font.render("Paused", True, WHITE)
                self.screen.blit(text, (WIDTH // 2 - text.get_width() // 2, 200))
                font = pygame.font.Font(None, 36)
                retry = font.render("Press P to continue", True, WHITE)
                self.screen.blit(retry, (WIDTH // 2 - retry.get_width() // 2, 250))
        elif model.game_state == "game_over":
            font = pygame.font.Font(None, 48)
            text = font.render("Game Over!", True, RED)
            self.screen.blit(text, (WIDTH // 2 - text.get_width() // 2, 200))
            font = pygame.font.Font(None, 36)
            retry = font.render("Press SPACE to return to menu", True, WHITE)
            self.screen.blit(retry, (WIDTH // 2 - retry.get_width() // 2, 250))
        elif model.game_state == "victory":
            font = pygame.font.Font(None, 48)
            text = font.render("You Win!", True, YELLOW)
            self.screen.blit(text, (WIDTH // 2 - text.get_width() // 2, 200))
            font = pygame.font.Font(None, 36)
            retry = font.render("Press SPACE to return to menu", True, WHITE)
            self.screen.blit(retry, (WIDTH // 2 - retry.get_width() // 2, 250))
        pygame.display.flip()

# Controller: Quản lý input và điều phối
class GameController:
    def __init__(self, model, view):
        self.model = model
        self.view = view
        self.running = True

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            elif event.type == pygame.KEYDOWN:
                if self.model.game_state == "menu":
                    if event.key == pygame.K_1:
                        self.model.difficulty = "easy"
                        self.model.ghost.set_difficulty(self.model.difficulty)
                        self.model.game_state = "playing"
                        self.model.reset()
                    elif event.key == pygame.K_2:
                        self.model.difficulty = "medium"
                        self.model.ghost.set_difficulty(self.model.difficulty)
                        self.model.game_state = "playing"
                        self.model.reset()
                    elif event.key == pygame.K_3:
                        self.model.difficulty = "hard"
                        self.model.ghost.set_difficulty(self.model.difficulty)
                        self.model.game_state = "playing"
                        self.model.reset()
                    elif event.key == pygame.K_4:
                        self.model.game_state = "leaderboard"
                elif self.model.game_state == "playing":
                    if event.key == pygame.K_p:
                        self.model.game_state = "paused"
                    elif event.key == pygame.K_UP:
                        self.model.pacman.set_direction((0, -1))
                    elif event.key == pygame.K_DOWN:
                        self.model.pacman.set_direction((0, 1))
                    elif event.key == pygame.K_LEFT:
                        self.model.pacman.set_direction((-1, 0))
                    elif event.key == pygame.K_RIGHT:
                        self.model.pacman.set_direction((1, 0))
                elif self.model.game_state == "paused":
                    if event.key == pygame.K_p:
                        self.model.game_state = "playing"
                elif self.model.game_state in ["game_over", "victory", "leaderboard"]:
                    if event.key == pygame.K_SPACE:
                        self.model.game_state = "menu"
                        self.model.reset()  # Đảm bảo trạng thái sạch khi quay lại menu

    def update(self, delta_time):
        self.model.update(delta_time)
        self.view.render(self.model)

# Lớp Pacman
class Pacman:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.direction = (0, 0)
        self.next_direction = (0, 0)

    def set_direction(self, direction):
        self.next_direction = direction

    def move(self, maze):
        try:
            if self.next_direction != (0, 0):
                new_x = self.x + self.next_direction[0]
                new_y = self.y + self.next_direction[1]
                if (0 <= new_x < len(maze[0]) and 0 <= new_y < len(maze) and 
                    maze[new_y][new_x] != 1):
                    self.x = new_x
                    self.y = new_y
                    self.direction = self.next_direction
                    self.next_direction = (0, 0)
                    if maze[self.y][self.x] == 2:
                        maze[self.y][self.x] = 0
                        return 10
            return 0
        except IndexError:
            print(f"IndexError in Pacman.move: x={self.x}, y={self.y}, next_direction={self.next_direction}")
            return 0

# Lớp Ghost
class Ghost:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.move_timer = 0
        self.move_delay = 0.3

    def set_difficulty(self, difficulty):
        if difficulty == "easy":
            self.move_delay = 0.3
        elif difficulty == "medium":
            self.move_delay = 0.08
        elif difficulty == "hard":
            self.move_delay = 0.0667

    def move(self, target_x, target_y, maze, delta_time):
        self.move_timer += delta_time
        if self.move_timer >= self.move_delay:
            path = bfs((self.x, self.y), (target_x, target_y), maze)
            if path and len(path) > 1:
                next_pos = path[1]
                self.x, self.y = next_pos
            self.move_timer -= self.move_delay

# BFS
def bfs(start, target, maze):
    queue = deque([(start, [start])])
    visited = {start}
    directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]

    while queue:
        (x, y), path = queue.popleft()
        if (x, y) == target:
            return path

        for dx, dy in directions:
            new_x, new_y = x + dx, y + dy
            if (0 <= new_x < len(maze[0]) and 0 <= new_y < len(maze) and
                maze[new_y][new_x] != 1 and (new_x, new_y) not in visited):
                visited.add((new_x, new_y))
                queue.append(((new_x, new_y), path + [(new_x, new_y)]))
    return []

# Main game loop
def setup():
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Pacman")
    model = GameModel()
    view = GameView(screen)
    controller = GameController(model, view)
    return controller

async def main():
    controller = setup()
    clock = pygame.time.Clock()
    while controller.running:
        delta_time = 1.0 / FPS
        controller.handle_events()
        controller.update(delta_time)
        await asyncio.sleep(delta_time)
        clock.tick(FPS)

if platform.system() == "Emscripten":
    asyncio.ensure_future(main())
else:
    if __name__ == "__main__":
        asyncio.run(main())